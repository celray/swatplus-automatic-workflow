"""------------------QSWAT+ Workflow v1.0.2 Settings File---------------"""

# Project Identification
Project_Name     = "robit"
Model_2_namelist = False        # True = get settings from existing model 
                                # False = get model from current settings

"""---------------------------   File Names  --------------------------"""
# Raster files (Should be projected with the same projection)
Topography         = "srtm_30m"
Soils              = "mowr_soil90"
Land_Use           = "roblandusenew"


# Database Files
Soil_Lookup        = "soil_lookup.csv"
Landuse_Lookup     = "landuse_lookup.csv"
Usersoil           = "usersoil.csv"

# Shape Files
Outlets             = "outlets.shp" # it should have same format as in the example

"""---------------------------  Project Options  ----------------------"""
# Watershed Deliniation (1 = Cells)
Ws_Thresholds_Type    = 1            
Channel_Threshold     = 200
Stream_Threshold      = 200
Out_Snap_Threshold    = 300                # metres 
Burn_In_Shape         = ""                 # leave as "" if none

#  -------------------  HRU Definition  ------------------
Slope_Classes         = "0, 9999"

# HRU creation method   (1 = Dominant landuse, soil, slope , 2 = Dominant HRU,
#                        3 = Filter by Area,                 4 = Target Number of HRUs,
#                        5 = Filter by landuse, soil, slope)

HRU_Filter_Method     = 3

# Thresholds_Type           (1 = Total Area (ha) , 2 = Percent)
HRU_Thresholds_Type   = 2
Land_Soil_Slope_Thres = "12, 10, 11"    # Thresholds for Landuse, Soil and Slope. Leave as "" if not needed
Target_Area           = 0               # used if HRU_Filter_Method 3 is selected
Target_Value          = 110             # used if HRU_Filter_Method 4 is selected

# Routing and ET and infiltration
ET_Method             = 2           # 1 = Priestley-Taylor, 2 = Penman-Monteith,
                                    # 3 = Hargreaves,      (4 = Observed - Not supported Currently)
Routing_Method        = 1           # 1 = Muskingum,        2 = Variable Storage
Routing_Timestep      = 1           # 1 = Daily Rainfall/routing, curve number
                                    # 2 = Sub-daily Rainfall/routing, Green & Ampt

# model run settings
Start_Year            = 1992
End_Year              = 1997
Warm_Up_Period        = 1           # the number of years for running the model without printing output

Print_CSV             = 1           # 0 = no, 1 = yes, selection to output csv files

Print_Objects         = {           # 1 = daily, 2 = month, 3 = year, 4 = annual average
                                    # default prints yearly results if not specified

                            "channel_sd"    : [1, 2, 3, 4],
                            "basin_nb"      : [2, 3, 4],
                            "basin_ls"      : [2, 3, 4],

                        }

Executable_Type         = 1             # 1 = Release, 2 = Debug   0 = Don't run

Cal_File                = ""            # a calibration.cal file with parameters for the calibrated model
                                        # leave as "" if there is no file to be used.

Calibrate               = False        # set to "True" to perform calibration, "False" to skip calibration
Calibration_Config_File = "calibration_config.csv"             # 
Number_of_Runs          =   4          # Set the number of runs for calibration
Number_of_Processes     =   7          # Set the number of parallel processes to make calibration faster

Make_Figures            = True         # set to "True" to create maps, "False" to skip map creation

# Log progress or not? If yes, you will not see updates
Keep_Log                = False        # True or False
"""---------------------------  Settings End  -----------------------"""
